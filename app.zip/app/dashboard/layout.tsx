'use client';

import React, { useEffect, useState } from 'react';
import MainSidebar from '@/components/MainSidebar';
import { useTheme } from '../../context/ThemeContext';
import Echo from 'laravel-echo';
import Pusher from 'pusher-js';

// 📡 ۱. ست کردن ریل‌تایم کلاینت لاراول اکو متصل به سرور Reverb لوکال
if (typeof window !== 'undefined' && !(window as any).Echo) {
  (window as any).Pusher = Pusher;
  (window as any).Echo = new Echo({
    broadcaster: 'reverb',
    key: 'wyBCijEJNkmFP5eoSDfSg6+bz0glNb8MnHwLLM6Mchk=', 
    wsHost: '127.0.0.1',
    wsPort: 8080,
    forceTLS: false,
    disableStats: true,
    enabledTransports: ['ws', 'wss'],
  });
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { isDark } = useTheme();
  const [openPopup, setOpenPopup] = useState(false);
  const [incomingCall, setIncomingCall] = useState<any>(null);
  const [currentUserId, setCurrentUserId] = useState<number | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedUser = localStorage.getItem('user_id');
      setCurrentUserId(storedUser ? Number(storedUser) : 1);
    }
  }, []);

  useEffect(() => {
    // 📡 ۲. شنود هوشمند با نام کامل نیم‌اسپیس کلاس رویداد لاراول
    if (typeof window !== 'undefined' && (window as any).Echo && currentUserId) {
      console.log(`📡 [LAYOUT LISTEN] در حال شنود کانال عمومی مرکز تلفن: agents.${currentUserId}`);
      
      const channel = (window as any).Echo.channel(`agents.${currentUserId}`);

      // 💡 اصلاح طلایی: شنود نام کامل رویداد مخابره شده توسط Reverb (با و بدون نقطه)
      const triggerPopup = (e: any) => {
        console.log("🚨 [WEBSOCKET SUCCESS] تماس در لایوت صید شد:", e);
        if (e && e.callData) {
          setIncomingCall(e.callData);
          setOpenPopup(true);
        }
      };

      // مهار کردن تمام حالت‌های ارسالی نام کلاس از بک‌بند
      channel.listen('App\\Events\\IncomingCallEvent', triggerPopup);
      channel.listen('.App\\Events\\IncomingCallEvent', triggerPopup);
      channel.listen('IncomingCallEvent', triggerPopup);
      channel.listen('.IncomingCallEvent', triggerPopup);
    }

    return () => {
      if (typeof window !== 'undefined' && (window as any).Echo && currentUserId) {
        (window as any).Echo.leave(`agents.${currentUserId}`);
      }
    };
  }, [currentUserId]);

  return (
    <div className={`min-h-screen flex transition-colors duration-300 ${isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`} dir="rtl">
      
      {/* 👤 ۱. منوی واحد پیشگامان */}
      <MainSidebar />

      {/* 💻 ۲. کادر رندر محتوای صفحات */}
      <div className="flex-1 pr-64 min-h-screen overflow-x-hidden">
        <main className="w-full h-full p-2">
          {children}
        </main>
      </div>

      {/* 📞 ۳. پاپ‌آ‌پ لوکس و نئونی تماس لایو */}
      {openPopup && incomingCall && (
        <div className={`fixed bottom-6 left-6 p-5 rounded-2xl shadow-2xl border z-50 w-80 animate-fadeIn transition-all ${
          isDark ? 'bg-slate-900/90 backdrop-blur-md border-slate-800 text-white' : 'bg-white/95 backdrop-blur-md border-slate-200 text-slate-800 shadow-xl'
        }`} dir="rtl">
          <div className="flex items-center justify-between border-b pb-2">
            <span className="font-black text-xs text-indigo-500 flex items-center gap-1.5 animate-pulse">
              🟢 تماس ورودی ریل‌تایم (VoIP)
            </span>
            <button type="button" onClick={() => setOpenPopup(false)} className="w-5 h-5 border rounded-full flex items-center justify-center hover:bg-rose-500 hover:text-white transition-colors text-slate-400 font-bold text-xs cursor-pointer">×</button>
          </div>
          
          <div className="mt-3 space-y-2 text-[11px] font-bold">
            <div className="flex justify-between"><span className="text-slate-400">👤 متقاضی:</span> <span className="text-indigo-500">{incomingCall.customer_name}</span></div>
            <div className="flex justify-between"><span className="text-slate-400">📱 شماره خط:</span> <span className="font-mono tracking-wider">{incomingCall.phone}</span></div>
            <div className="flex justify-between"><span className="text-slate-400">🌍 کشور هدف:</span> <span>{incomingCall.target_country || '---'}</span></div>
            
            <div className="pt-3 border-t flex gap-2">
              <a href={`/dashboard/leads`} className="bg-indigo-600 hover:bg-indigo-700 text-white text-center font-bold py-2 px-3 rounded-xl w-full transition-all block text-[10px]">
                📂 باز کردن کارتابل پرونده
              </a>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}