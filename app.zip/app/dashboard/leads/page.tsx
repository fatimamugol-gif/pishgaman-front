'use client';

import React, { useEffect, useState, useRef } from 'react';
import Link from 'next/link';
import PermissionGuard from '@/components/PermissionGuard';
import LeadDrawer from '@/components/LeadDrawer';

export default function LeadsDashboardPage() {
  const [leads, setLeads] = useState<any[]>([]);
  const [filteredLeads, setFilteredLeads] = useState<any[]>([]);
  const [selectedLead, setSelectedLead] = useState<any>(null);
  const [sources, setSources] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  // مدیریت منوی ۳ نقطه شناور سطرها
  const [activeMenuId, setActiveMenuId] = useState<number | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);

  // وضعیت فیلترها و سرچ لایو
  const [filterSource, setFilterSource] = useState('all');
  const [filterPlan, setFilterPlan] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const loadData = () => {
    setLoading(true);
    const token = localStorage.getItem('token');
    const authHeaders = {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };

    fetch('http://127.0.0.1:8000/api/next/dashboard/leads', { headers: authHeaders })
      .then(res => {
        if (res.status === 401) {
          localStorage.clear();
          document.cookie = "pishgaman_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
          window.location.href = '/auth';
          return;
        }
        return res.json();
      })
      .then(resData => {
        if (resData) {
          setLeads(resData.data || []);
          setFilteredLeads(resData.data || []);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("خطا در فچ اطلاعات:", err);
        setLoading(false);
      });
  };

  useEffect(() => {
    loadData();
    const handleOutsideClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setActiveMenuId(null);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // اعمال لایو فیلترهای ترکیبی و سرچ متمرکز
  useEffect(() => {
    let result = leads;
    if (filterSource !== 'all') result = result.filter(l => l.source === filterSource);
    if (filterPlan !== 'all') result = result.filter(l => l.requested_plan === filterPlan);
    if (searchQuery) {
      result = result.filter(l =>
        (l.name && l.name.includes(searchQuery)) || (l.phone && l.phone.includes(searchQuery))
      );
    }
    setFilteredLeads(result);
  }, [filterSource, filterPlan, searchQuery, leads]);

  const handleUpdateLead = async (updatedLead: any) => {
    const token = localStorage.getItem('token');
    try {
      const res = await fetch(`http://127.0.0.1:8000/api/next/leads/update/${updatedLead.id}`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(updatedLead)
      });
      const data = await res.json();
      if (data.status === 'success') {
        loadData();
        setSelectedLead(null);
      }
    } catch (err) {
      alert('خطا در ذخیره‌سازی اطلاعات.');
    }
  };

  const handleVoipCall = async (phone: string, leadId: number) => {
  const token = localStorage.getItem('token');
  
  try {
    const res = await fetch('http://127.0.0.1:8000/api/next/voip/click-to-dial', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({ customer_phone: phone, lead_id: leadId })
    });
    const data = await res.json();
    if (data.status === 'success') {
      console.log('☎️ سیگنال شلیک شد:', data.message);
    } else {
      alert('❌ خطا در مرکز تلفن: ' + data.message);
    }
  } catch (err) {
    console.error(err);
  }
};

  const handleDelete = async (id: number) => {
    const token = localStorage.getItem('token');
    if (confirm('👑 ناظر گرامی، از حذف دائمی این پرونده مطمئن هستید؟')) {
      const res = await fetch(`http://127.0.0.1:8000/api/next/leads/delete/${id}`, { 
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.status === 'success') {
        loadData();
      }
    }
  };

  const totalCount = leads.length;
  const nextFrontCount = leads.filter(l => (l.source || '').includes('فرانت') || (l.source || '').includes('دستی')).length;
  const perfexCount = totalCount - nextFrontCount;

  if (loading) return <div className="p-20 text-center text-xs text-slate-500" dir="rtl">⏳ در حال همگام‌سازی نهایی ماژول چهل‌گانه پیشگامان...</div>;

  return (
    <div className="p-6 bg-slate-50 min-h-screen text-right font-sans text-[11px]" dir="rtl">

      {/* هدر بالایی لایو مشابه تصویر */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 bg-white p-5 rounded-2xl border border-slate-100 shadow-xs">
        <div>
          <h1 className="text-xl font-black text-slate-800">🦾 میزکار متمرکز مدیریت ۳۶۰ درجه متقاضیان</h1>
          <p className="text-slate-400 text-[10px] mt-0.5">نمایش کامل تمام ستون‌های نظارتی همگام با دیتابیس قدیمی پرفکس</p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/leads/new" className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl font-bold text-xs transition-all shadow-sm">
            ➕ مشاوره اولیه جدید
          </Link>
        </div>
      </div>

      {/* کارت‌های KPI پایش کل متقاضیان */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-xl border flex justify-between items-center shadow-2xs">
          <div><p className="text-slate-400 font-bold text-[10px]">کل پرونده‌ها</p><h3 className="text-xl font-black mt-0.5 text-slate-800">{totalCount} نفر</h3></div>
          <div className="w-8 h-8 bg-indigo-50 text-indigo-600 flex items-center justify-center rounded-lg text-sm">🎯</div>
        </div>
        <div className="bg-white p-4 rounded-xl border flex justify-between items-center shadow-2xs">
          <div><p className="text-slate-400 font-bold text-[10px]">ورود دستی فرانت</p><h3 className="text-xl font-black mt-0.5 text-emerald-600">{nextFrontCount} مورد</h3></div>
          <div className="w-8 h-8 bg-emerald-50 text-emerald-600 flex items-center justify-center rounded-lg text-sm">⚡</div>
        </div>
        <div className="bg-white p-4 rounded-xl border flex justify-between items-center shadow-2xs">
          <div><p className="text-slate-400 font-bold text-[10px]">سورس پرفکس</p><h3 className="text-xl font-black mt-0.5 text-amber-500">{perfexCount} مورد</h3></div>
          <div className="w-8 h-8 bg-amber-50 text-amber-500 flex items-center justify-center rounded-lg text-sm">🔄</div>
        </div>
      </div>

      {/* فیلترهای پيشرفته آبشاری */}
      <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-2xs mb-4 grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
        <input type="text" placeholder="جستجوی نام، فامیل یا شماره متقاضی..." className="p-2 bg-slate-50 border rounded-lg text-xs outline-none" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
        <select className="p-2 bg-slate-50 border rounded-lg text-xs outline-none text-slate-600 font-bold cursor-pointer" value={filterSource} onChange={e => setFilterSource(e.target.value)}>
          <option value="all">🔍 همه منابع ورودی</option>
          <option value="ورود دستی فرانت">ورود دستی فرانت</option>
          <option value="ایمپورت پرفکس">ایمپورت‌های Perfex CRM</option>
          <option value="پیشگامان">پیشگامان</option>
          <option value="تهران ویزا">تهران ویزا</option>
          <option value="اینستاگرام">اینستاگرام</option>
        </select>
        <select className="p-2 bg-slate-50 border rounded-lg text-xs outline-none text-slate-600 font-bold cursor-pointer" value={filterPlan} onChange={e => setFilterPlan(e.target.value)}>
          <option value="all">✈️ همه پلن‌های مهاجرتی</option>
          <option value="مهاجرت تحصیلی">مهاجرت تحصیلی</option>
          <option value="آوسبیلدونگ">آوسبیلدونگ</option>
          <option value="جاب آفر / کاری">جاب آفر / کاری</option>
          <option value="تمکن مالی / سرمایه‌گذاری">تمکن مالی / سرمایه‌گذاری</option>
        </select>
      </div>

      {/* 📊 رندر ۱۰۰٪ تمام ستون‌های تصویر مرجع image_9552e1.png */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse whitespace-nowrap">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-100 text-slate-500 font-bold text-[10px] h-10 select-none">
                <th className="p-3 text-center w-8"><input type="checkbox" className="rounded text-indigo-600 accent-indigo-600" /></th>
                <th className="p-3">#</th>
                <th className="p-3">نام</th>
                <th className="p-3">شماره تلفن</th>
                <th className="p-3 text-center">امتیاز</th>
                <th className="p-3 text-center">سطح</th>
                <th className="p-3">منتسب به</th>
                <th className="p-3">وضعیت</th>
                <th className="p-3">منبع</th>
                <th className="p-3">لینک فرم ورودی</th>
                <th className="p-3">آخرین تماس</th>
                <th className="p-3">ایجاد شده</th>
                <th className="p-3 text-center">مشاوره عالی✔️</th>
                <th className="p-3 text-center">تاریخ جلسه⏰</th>
                <th className="p-3 text-center">تماس بعدی☎️</th>
                <th className="p-3 text-center">ناظر⚠️</th>
                <th className="p-3 text-center">عملیات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 text-slate-600">
              {filteredLeads.map((lead: any) => (
                <tr key={lead.id} className="hover:bg-slate-50/40 transition-colors h-12 cursor-pointer" onClick={() => setSelectedLead(lead)}>
                  <td className="p-3 text-center" onClick={e => e.stopPropagation()}><input type="checkbox" className="rounded accent-indigo-600" /></td>
                  <td className="p-3 font-mono text-slate-400">{lead.id + 46298}</td>
                  <td className="p-3 font-bold text-slate-800">{lead.name}</td>
                  <td className="p-3 font-mono text-slate-500">{lead.phone || 'ثبت نشده'}</td>
                  <td className="p-3 text-center font-mono font-bold text-indigo-600">{lead.score || lead.gpa || '70'}</td>
                  <td className="p-3 text-center">
                    <span className="inline-flex items-center gap-1 font-bold text-slate-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                      {lead.level || lead.education_level || 'متوسط'}
                    </span>
                  </td>
                  <td className="p-3">
                    <div className="flex items-center gap-1.5">
                      <div className="w-4 h-4 rounded-full bg-indigo-950 flex items-center justify-center text-white font-bold text-[7px]">P</div>
                      <span className="font-bold text-slate-700">{lead.assigned_agent || 'تخصیص آزاد'}</span>
                    </div>
                  </td>
                  <td className="p-3" onClick={e => e.stopPropagation()}>
                    <span className="border border-purple-200 text-purple-700 bg-purple-50/40 px-2 py-0.5 rounded-md font-black text-[10px] inline-flex items-center gap-1">
                      {lead.status || 'مشاوره جدید'} ▼
                    </span>
                  </td>
                  <td className="p-3 text-slate-500 font-bold">{lead.source || 'پیشگامان'}</td>
                  <td className="p-3 font-mono text-sky-600 max-w-[130px] truncate" title={lead.form_link}>{lead.form_link}</td>
                  <td className="p-3 text-slate-400 font-medium">{lead.last_contact || 'یک ساعت پیش'}</td>
                  <td className="p-3 text-slate-400 font-medium border-l border-dashed border-slate-100">{lead.created_at_text || 'یک ساعت پیش'}</td>
                  <td className="p-3 text-center text-emerald-600 font-black text-xs select-none">✓</td>
                  <td className="p-3 text-center font-mono text-slate-400">{lead.session_date_shamsi || '---'}</td>
                  <td className="p-3 text-center font-bold text-indigo-600 bg-indigo-50/40 font-mono">{lead.next_call_date_shamsi || '---'}</td>
                  <td className="p-3 text-center text-amber-500 text-xs">⚠️</td>
                  
                  {/* منوی ۳ نقطه شناور اتمیک */}
                  <td className="p-3 text-center overflow-visible" onClick={e => e.stopPropagation()}>
                    <div className="relative inline-block">
                      <button onClick={() => setActiveMenuId(activeMenuId === lead.id ? null : lead.id)} className="bg-slate-100 hover:bg-slate-200 text-slate-700 w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs shadow-2xs cursor-pointer">⋮</button>
                      {activeMenuId === lead.id && (
                        <div ref={menuRef} className="absolute right-0 mt-1 w-32 bg-white border rounded-xl shadow-lg py-1 z-50 text-right">
                          <button onClick={() => { setSelectedLead(lead); setActiveMenuId(null); }} className="w-full text-right px-3 py-1.5 text-slate-700 hover:bg-slate-50 font-bold flex items-center gap-1">👁️ نمایش ۳۶0</button>
                          <button
                              onClick={() => handleVoipCall(lead.phone, lead.id)}
                              className="flex items-center gap-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-black px-2.5 py-1.5 rounded-xl transition-all shadow-md text-[10px] cursor-pointer"
                            >
                              <span>📞</span> تماس هوشمند
                            </button>
                          <PermissionGuard permissionKey="delete_leads">
                            <button onClick={() => { handleDelete(lead.id); setActiveMenuId(null); }} className="w-full text-right px-3 py-1.5 text-rose-600 hover:bg-rose-50 font-bold flex items-center gap-1">🗑️ حذف دائم</button>
                          </PermissionGuard>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* لود هوشمند کامپوننت مستقل دراور چهل‌گانه شناسنامه */}
      {selectedLead && (
        <LeadDrawer lead={selectedLead} onClose={() => setSelectedLead(null)} onUpdate={handleUpdateLead} />
      )}

    </div>
  );
}