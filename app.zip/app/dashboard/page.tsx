'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';

export default function AgentDashboardMainPage() {
  const [hubData, setHubData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [userName, setUserName] = useState('کارشناس محترم');
  
  // 📡 استیت‌های مدیریت لایو پاپ‌آپ تماس
  const [openPopup, setOpenPopup] = useState(false);
  const [incomingCall, setIncomingCall] = useState<any>(null);
  const [currentUserId, setCurrentUserId] = useState<number | null>(null);

  const fetchHubData = async () => {
    const token = localStorage.getItem('token');
    const storedName = localStorage.getItem('user_name');
    if (storedName) setUserName(storedName);

    try {
      const res = await fetch('http://127.0.0.1:8000/api/next/agent/dashboard-hub', {
        headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
      });
      const data = await res.json();
      if (data.status === 'success') {
        setHubData(data);
      }
    } catch (err) {
      console.error("خطا در بارگذاری اطلاعات هب:", err);
    } finally {
      setLoading(false);
    }
  };

  // ۱. فچ اولیه اطلاعات کارتابل
  useEffect(() => { 
    fetchHubData(); 
    if (typeof window !== 'undefined') {
      const storedUser = localStorage.getItem('user_id');
      setCurrentUserId(storedUser ? Number(storedUser) : 1);
    }
  }, []);

  // ۲. 📡 لیسنر مستقیم و آنلاین وب‌سوکت Reverb درون هسته میزکار
  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).Echo && currentUserId) {
      console.log(`📡 [HUB LISTEN] در حال شنود کانال عمومی مرکز تلفن: agents.${currentUserId}`);
      
      const channel = (window as any).Echo.channel(`agents.${currentUserId}`);
      
      const handleIncomingCall = (e: any) => {
        console.log("🚨 [WEBSOCKET LIVE SUCCESS] سیگنال آنلاین آستریسک روی فرانت صید شد:", e);
        if (e && e.callData) {
          setIncomingCall(e.callData);
          setOpenPopup(true);
          fetchHubData(); // رفرش خودکار کارتابل با آمدن زنگ
        }
      };

      // مهار قطعی تمام فرمت‌های نام کلاس ارسالی از طرف لاراول ریورب
      channel.listen('App\\Events\\IncomingCallEvent', handleIncomingCall);
      channel.listen('.App\\Events\\IncomingCallEvent', handleIncomingCall);
      channel.listen('IncomingCallEvent', handleIncomingCall);
      channel.listen('.IncomingCallEvent', handleIncomingCall);
    }

    // گارد تست آفلاین کنسول
    const handleManualTrigger = (e: any) => {
      console.log("🚨 [MANUAL TRIGGER SUCCESS] دیتای فیک صید شد:", e.detail);
      if (e && e.detail) {
        setIncomingCall(e.detail);
        setOpenPopup(true);
      }
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('triggerFakeCall', handleManualTrigger);
    }

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('triggerFakeCall', handleManualTrigger);
        if ((window as any).Echo && currentUserId) {
          (window as any).Echo.leave(`agents.${currentUserId}`);
        }
      }
    };
  }, [currentUserId]);

  if (loading) {
    return (
      <div className="p-20 text-center text-xs text-slate-500 font-sans" dir="rtl">
        ⏳ در حال آماده‌سازی کارتابل و چک کردن زنگ‌های امروز پیشگامان...
      </div>
    );
  }

  const metrics = hubData?.metrics || { total_leads: 0, pending_tasks_count: 0, today_reminders_count: 0 };

  return (
    <div className="p-8 space-y-8 bg-[#f4f6fa] min-h-screen text-[#2d3748] font-sans text-[11px]" dir="rtl">
      
      {/* 📋 هدر بالای صفحه به سبک Jaida */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-xl font-black tracking-tight text-slate-900">تحلیل وضعیت کارتابل (Analytics)</h1>
          <p className="text-[11px] text-slate-400 mt-1">خوش‌آمدید مهندس {userName} رفیق گرامی؛ بیایید فلوهای امروز را جلو ببریم.</p>
        </div>
        
        <div className="relative">
          <input 
            type="text" 
            placeholder="جستجو در کارتابل..." 
            className="bg-white border-none shadow-[0_4px_20px_rgba(0,0,0,0.02)] rounded-xl py-2 px-4 pr-9 text-[11px] w-64 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-700 transition-all"
          />
          <span className="absolute right-3 top-2.5 text-slate-400">🔍</span>
        </div>
      </div>

      {/* 📊 ردیف اول: کارت‌های آماری */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* ۱. کادر آخرین یادآورها */}
        <div className="bg-white p-6 rounded-[24px] shadow-[0_8px_30px_rgba(0,0,0,0.03)] border border-white space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b pb-3 mb-2">
              <h2 className="font-black text-xs text-slate-800">☎️ آلارم زنگ‌های امروز</h2>
              <span className="bg-rose-50 text-rose-600 px-2 py-0.5 rounded-lg text-[9px] font-bold">اقدام فوری</span>
            </div>
            <div className="space-y-3 max-h-[180px] overflow-y-auto">
              {hubData?.recent_reminders?.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-[10px]">هیچ آلارم تماس عقب‌افتاده‌ای نداری رفیق. ✨</div>
              ) : (
                hubData?.recent_reminders?.map((rem: any) => (
                  <div key={rem.id} className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl hover:bg-slate-100/60 transition-all">
                    <div>
                      <div className="font-black text-xs text-slate-800">{rem.title}</div>
                      <div className="text-[9px] text-slate-400 font-medium mt-0.5">{rem.description || 'بدون توضیحات'}</div>
                    </div>
                    <span className="bg-rose-100 text-rose-700 px-2 py-0.5 rounded font-mono font-bold text-[10px]">
                      {rem.reminder_time || '09:00'}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
          <div className="text-slate-400 text-[10px] pt-2 border-t font-medium">
            جمع کل یادآورها: <span className="font-mono font-bold text-rose-600">{metrics.today_reminders_count} اعلان</span>
          </div>
        </div>

        {/* ۲. راندمان پیشرفت دایره‌ای */}
        <div className="bg-white p-6 rounded-[24px] shadow-[0_8px_30px_rgba(0,0,0,0.03)] border border-white flex flex-col justify-between">
          <h2 className="font-black text-xs text-slate-800">راندمان پردازش اقدامات</h2>
          <div className="flex items-center justify-between my-2">
            <div className="space-y-1">
              <div className="text-[10px] text-slate-400 font-bold">وضعیت وظایف من:</div>
              <div className="text-xs font-black text-indigo-950">پرونده‌های فعال کارتابل</div>
              <div className="text-[10px] text-slate-400 mt-2">تسک‌های در انتظار:</div>
              <div className="font-mono text-xs font-black text-amber-600">{metrics.pending_tasks_count} اقدام معلق</div>
            </div>
            
            <div className="relative w-24 h-24 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path className="text-slate-100" strokeWidth="3" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                <path className="text-indigo-600" strokeDasharray="65, 100" strokeWidth="3" strokeLinecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
              </svg>
              <div className="absolute font-mono font-black text-xs text-slate-800">65%</div>
            </div>
          </div>
          <div className="bg-sky-50 text-sky-700 p-2.5 rounded-xl text-[10px] font-bold text-center">
            💼 شما در حال حاضر مدیریت <span className="font-mono font-black">{metrics.total_leads} پرونده</span> را بر عهده دارید.
          </div>
        </div>

        {/* ۳. ساید-کارت غنی مدیریتی بنفش */}
        <div className="bg-gradient-to-br from-indigo-950 to-indigo-900 text-white p-6 rounded-[24px] shadow-[0_12px_40px_rgba(49,46,129,0.15)] flex flex-col justify-between">
          <div className="flex justify-between items-center">
            <h2 className="font-black text-xs opacity-90">وضعیت زنده پورتال پیشگامان</h2>
            <span className="text-xs opacity-60 select-none">•••</span>
          </div>
          
          <div className="my-4 space-y-2">
            <div className="flex justify-between items-center text-[11px]">
              <span className="opacity-70">امروز:</span>
              <span className="font-bold text-sky-300">{new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium' }).format(new Date())}</span>
            </div>
            <div className="flex justify-between items-center text-[11px]">
              <span className="opacity-70">گارد اتصال مرکز تلفن:</span>
              <span className="text-emerald-400 font-bold">اتصال زنده (AMI)</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl flex justify-between items-center">
            <div>
              <div className="text-[10px] opacity-90 font-bold">پایش هوشمند نرخ تبدیل</div>
              <div className="text-[9px] opacity-65">سیستم مانیتورینگ آماده است.</div>
            </div>
            <Link href="/dashboard/leads" className="bg-white text-indigo-950 px-2.5 py-1 rounded-lg font-bold text-[9px] hover:bg-slate-100 transition-all">
              ورود به کارتابل
            </Link>
          </div>
        </div>

      </div>

      {/* 📉 ردیف دوم: تسک‌ها و ددلاین‌ها */}
      <div className="bg-white p-6 rounded-[24px] shadow-[0_8px_30px_rgba(0,0,0,0.03)] border border-white space-y-4">
        <div className="border-b pb-3 flex justify-between items-center">
          <h3 className="text-xs font-black text-slate-800">📋 تسک‌ها و ددلاین‌های مشاوره‌ای جاری</h3>
          <span className="text-slate-400 text-[10px] font-mono">توزیع ماهانه اقدامات</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
          <div className="md:col-span-2 space-y-2 max-h-[160px] overflow-y-auto">
            {hubData?.recent_tasks?.length === 0 ? (
              <div className="text-center py-8 text-slate-400 border border-dashed rounded-xl">لیست وظایف جاری شما مرتب است. 🟢</div>
            ) : (
              hubData?.recent_tasks?.map((task: any) => (
                <div key={task.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex justify-between items-center hover:bg-slate-100/50 transition-all">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
                    <h4 className="font-bold text-slate-700">{task.task_title}</h4>
                  </div>
                  <span className="text-slate-400 font-mono text-[10px]">📅 ددلاین: {task.due_date_shamsi || '---'}</span>
                </div>
              ))
            )}
          </div>

          <div className="flex justify-between items-end h-32 pt-2 font-mono text-[8px] text-slate-400 border-r pr-4">
            <div className="flex flex-col items-center gap-1 w-full"><div style={{ height: '35px' }} className="w-3.5 bg-indigo-600 rounded-t-md" /><span>01</span></div>
            <div className="flex flex-col items-center gap-1 w-full"><div style={{ height: '55px' }} className="w-3.5 bg-indigo-600 rounded-t-md" /><span>02</span></div>
            <div className="flex flex-col items-center gap-1 w-full"><div style={{ height: '25px' }} className="w-3.5 bg-indigo-600 rounded-t-md" /><span>03</span></div>
            <div className="flex flex-col items-center gap-1 w-full"><div style={{ height: '65px' }} className="w-3.5 bg-indigo-600 rounded-t-md" /><span>04</span></div>
            <div className="flex flex-col items-center gap-1 w-full"><div style={{ height: '45px' }} className="w-3.5 bg-indigo-600 rounded-t-md" /><span>05</span></div>
            <div className="flex flex-col items-center gap-1 w-full"><div style={{ height: '75px' }} className="w-3.5 bg-indigo-600 rounded-t-md" /><span>06</span></div>
          </div>
        </div>
      </div>

      {/* 📞 ۳. پاپ‌آپ لوکس و نئونی زنده */}
      {openPopup && incomingCall && (
        <div className="fixed bottom-6 left-6 p-5 rounded-2xl border z-50 w-80 animate-fadeIn transition-all bg-white/95 backdrop-blur-md border-slate-200 text-slate-800 shadow-2xl" dir="rtl">
          <div className="flex items-center justify-between border-b pb-2">
            <span className="font-black text-xs text-indigo-500 flex items-center gap-1.5 animate-pulse">
              🟢 تماس ورودی ریل‌تایم (VoIP)
            </span>
            <button type="button" onClick={() => setOpenPopup(false)} className="w-5 h-5 border rounded-full flex items-center justify-center hover:bg-rose-500 hover:text-white transition-colors text-slate-400 font-bold text-xs cursor-pointer">×</button>
          </div>
          
          <div className="mt-3 space-y-2 text-[11px] font-bold">
            <div className="flex justify-between"><span className="text-slate-400">👤 متقاضی:</span> <span className="text-indigo-500">{incomingCall.customer_name}</span></div>
            <div className="flex justify-between"><span className="text-slate-400">📱 شماره خط:</span> <span className="font-mono tracking-wider">{incomingCall.phone}</span></div>
            <div className="flex justify-between"><span className="text-slate-400">🌍 کشور هدف:</span> <span>{incomingCall.target_country || '---'}</span></div>
            
            <div className="pt-3 border-t flex gap-2">
              <a href={`/dashboard/leads`} className="bg-indigo-600 hover:bg-indigo-700 text-white text-center font-bold py-2 px-3 rounded-xl w-full transition-all block text-[10px]">
                📂 باز کردن کارتابل پرونده
              </a>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}