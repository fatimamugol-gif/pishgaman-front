'use client';

import React, { useEffect, useState } from 'react';

export default function SupervisorReportsPage() {
  const [reportData, setReportData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchReports = async () => {
    setLoading(true);
    const token = localStorage.getItem('token');
    try {
      const res = await fetch('http://127.0.0.1:8000/api/next/supervisor/reports', {
        headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' }
      });
      if (res.status === 403) {
        alert('🚫 دسترسی مخصوص ناظر ارشد سیستم است.');
        window.location.href = '/dashboard';
        return;
      }
      const data = await res.json();
      if (data.status === 'success') setReportData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchReports(); }, []);

  if (loading) return <div className="p-20 text-center text-xs text-slate-500" dir="rtl">⏳ در حال تجمیع ماتریکس چهل‌گانه و رصد راندمان کارشناسان پیشگامان...</div>;

  return (
    <div className="p-6 bg-slate-50 min-h-screen text-right font-sans text-[11px]" dir="rtl">
      
      {/* هدر بالایی پنل نظارت */}
      <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-2xs mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-lg font-black text-slate-800">📊 اتاق پایش، آنالیز و مانیتورینگ استراتژیک ناظر</h1>
          <p className="text-slate-400 text-[10px] mt-0.5">رصد زنده بار ترافیکی دپارتمان‌ها، تفکیک ۱۱ پرسونای روانشناختی و لیدربورد کارشناسان کال‌سنتر</p>
        </div>
        <button onClick={fetchReports} className="bg-indigo-600 text-white font-bold px-4 py-2 rounded-xl text-xs hover:bg-indigo-700 transition-all cursor-pointer">🔄 به‌روزرسانی لایو آمار</button>
      </div>

      {/* بخش اول: پروگرس‌بارهای توزیع دپارتمان‌ها و وضعیت‌های بنفش */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        
        {/* ۱. توزیع متقاضیان در دپارتمان‌های فیزیکی سازمان */}
        <div className="bg-white p-5 rounded-2xl border shadow-2xs space-y-3">
          <h3 className="text-xs font-black text-slate-800 border-b pb-2 flex items-center gap-1">🏢 ترافیک متقاضیان بر اساس دپارتمان‌ها</h3>
          <div className="space-y-3 pt-1">
            {reportData?.department_distribution?.map((dep: any, i: number) => (
              <div key={i} className="space-y-1">
                <div className="flex justify-between font-bold text-slate-700">
                  <span>{dep.name}</span>
                  <span className="font-mono text-indigo-600">{dep.total_leads} لید</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-indigo-600 h-full transition-all" style={{ width: `${Math.min(dep.total_leads * 4, 100)}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ۲. وضعیت لیدها و نرخ تبدیل */}
        <div className="bg-white p-5 rounded-2xl border shadow-2xs space-y-3">
          <h3 className="text-xs font-black text-slate-800 border-b pb-2 flex items-center gap-1">🎛️ مانیتورینگ وضعیت لیدها (مرحله پیگیری)</h3>
          <div className="space-y-3 pt-1">
            {reportData?.status_distribution?.map((st: any, i: number) => (
              <div key={i} className="space-y-1">
                <div className="flex justify-between font-bold text-slate-700">
                  <span>{st.status || 'مشاوره جدید'}</span>
                  <span className="font-mono text-purple-700 bg-purple-50 px-2 py-0.5 rounded border text-[10px] font-black">{st.count} مورد</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-purple-600 h-full transition-all" style={{ width: `${Math.min(st.count * 6, 100)}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* 🏆 لیدربورد عملکرد کارشناسان (Agent Leaderboard) مطابق با گزارشات داکیومنت شما */}
      <div className="bg-white p-5 rounded-2xl border shadow-2xs">
        <h3 className="text-xs font-black text-slate-800 border-b pb-3 mb-3">🏆 کارنامه، راندمان و ظرفیت پایش کارشناسان فروش</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse whitespace-nowrap">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-bold h-10 select-none">
                <th className="p-3">نام مشاور / کارشناس دپارتمان</th>
                <th className="p-3 text-center">تعداد لید منتسب شده</th>
                <th className="p-3 text-center">مشاوره‌های باقیمانده روز</th>
                <th className="p-3 text-center text-rose-600">🚨 تماس‌های وضعیت‌سنجی نشده</th>
                <th className="p-3 text-center">پیگیری‌های به سرانجام رسیده (Done)</th>
                <th className="p-3 text-center">شاخص راندمان تیمی (Progress)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 text-slate-700">
              {reportData?.agent_performance?.map((agent: any, i: number) => (
                <tr key={i} className="hover:bg-slate-50/50 h-12 transition-colors">
                  <td className="p-3 font-bold text-slate-800">💼 {agent.name}</td>
                  <td className="p-3 text-center font-mono font-bold text-slate-700">{agent.total_leads} لید</td>
                  <td className="p-3 text-center font-mono text-amber-600 font-bold">{agent.pending_tasks} مشاورہ</td>
                  <td className="p-3 text-center font-mono font-black text-rose-600 bg-rose-50/30">
                    {agent.unreported_calls > 0 ? `🚨 ${agent.unreported_calls} مورد` : '🟢 0 مورد'}
                  </td>
                  <td className="p-3 text-center font-mono text-emerald-600 font-bold">{agent.done_tasks} تسک موفق</td>
                  <td className="p-3 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <span className="bg-indigo-600 text-white font-mono px-1.5 py-0.5 rounded font-bold text-[10px] min-w-[32px] text-center">%{agent.efficiency}</span>
                      <div className="w-16 bg-slate-100 h-1.5 rounded-full overflow-hidden inline-block">
                        <div className="bg-indigo-600 h-full" style={{ width: `${agent.efficiency}%` }}></div>
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}