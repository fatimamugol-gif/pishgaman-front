'use client';

import React, { useEffect, useState } from 'react';

export default function UsersAndDepartmentsManagement() {
  const [panelTab, setPanelTab] = useState<'users' | 'departments'>('users');
  const [users, setUsers] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // استیت‌های مودال کاربران
  const [editingUser, setEditingUser] = useState<any>(null);
  const [newPassword, setNewPassword] = useState('');
  const [showCreateUserModal, setShowCreateModal] = useState(false);
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', role: 'agent', department_id: '' });

  // استیت‌های مودال دپارتمان‌ها
  const [editingDept, setEditingDept] = useState<any>(null);

  const loadAllData = async () => {
    setLoading(true);
    const token = localStorage.getItem('token');
    const headers = { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' };

    try {
      const uRes = await fetch('http://127.0.0.1:8000/api/next/users', { headers });
      const uData = await uRes.json();
      if (uData.status === 'success') setUsers(uData.data || []);

      const dRes = await fetch('http://127.0.0.1:8000/api/next/departments', { headers });
      const dData = await dRes.json();
      if (dData.status === 'success') setDepartments(dData.data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadAllData(); }, []);

  // ثبت / ویرایش دپارتمان
  const handleSaveDepartment = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    const res = await fetch('http://127.0.0.1:8000/api/next/departments/store', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(editingDept)
    });
    if (res.ok) {
      alert('اطلاعات و پرمیشن‌های پایه دپارتمان با موفقیت مستقر شدند.');
      setEditingDept(null);
      loadAllData();
    }
  };

  // ثبت کاربر جدید
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    const res = await fetch('http://127.0.0.1:8000/api/next/users/store', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(newUser)
    });
    if (res.ok) {
      alert('کاربر جدید ایجاد شد.');
      setShowCreateModal(false);
      setNewUser({ name: '', email: '', password: '', role: 'agent', department_id: '' });
      loadAllData();
    }
  };

  // ویرایش جامع کاربر (شامل دپارتمان، وضعیت و پرمیشن اورراید)
  const handleUserUpdate = async () => {
    const token = localStorage.getItem('token');
    const res = await fetch(`http://127.0.0.1:8000/api/next/users/update/${editingUser.id}`, {
      method: 'PUT',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: editingUser.name,
        role: editingUser.role,
        status: editingUser.status,
        department_id: editingUser.department_id ? parseInt(editingUser.department_id) : null,
        password: newPassword,
        permissions: editingUser.permissions_parsed || {}
      })
    });
    if (res.ok) {
      alert('تغییرات پروفایل، وضعیت حساب و پرمیشن‌های اختصاصی اعمال شد.');
      setEditingUser(null);
      setNewPassword('');
      loadAllData();
    }
  };

  const openUserEdit = (user: any) => {
    let permissions_parsed = { view_all_leads: false, delete_leads: false, export_excel: false, edit_settings: false, menu_leads: true, menu_reports: false };
    try { if (user.permissions) permissions_parsed = { ...permissions_parsed, ...JSON.parse(user.permissions) }; } catch (e) { }
    setEditingUser({ ...user, permissions_parsed });
  };

  if (loading) return <div className="p-20 text-center text-xs font-sans text-slate-500" dir="rtl">⏳ در حال بارگذاری زیرساخت امنیتی پیشگامان...</div>;

  return (
    <div className="p-8 bg-slate-50 min-h-screen text-right font-sans text-xs" dir="rtl">

      {/* سوییچرهای پنل بالا */}
      <div className="flex gap-4 mb-6 bg-white p-4 rounded-2xl border">
        <button onClick={() => setPanelTab('users')} className={`px-5 py-2.5 rounded-xl font-bold transition-all cursor-pointer ${panelTab === 'users' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 text-slate-600'}`}>💼 مدیریت کاربران و دسترسی‌ها</button>
        <button onClick={() => setPanelTab('departments')} className={`px-5 py-2.5 rounded-xl font-bold transition-all cursor-pointer ${panelTab === 'departments' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 text-slate-600'}`}>🏢 مدیریت دپارتمان‌ها و مجوزهای منو</button>
      </div>

      {/* ==================== تب اول: کاربران ==================== */}
      {panelTab === 'users' && (
        <div className="space-y-4">
          <div className="bg-white p-6 rounded-2xl border flex justify-between items-center">
            <div>
              <h2 className="text-base font-black text-slate-800">🛡️ ماتریس کاربران دپارتمان</h2>
              <p className="text-slate-400 text-[11px] mt-0.5">تغییر زنده وضعیت حساب، دپارتمان فعال و پرمیشن‌های استثنای کلاینت</p>
            </div>
            <button onClick={() => setShowCreateModal(true)} className="bg-indigo-600 text-white p-2 rounded-xl font-bold cursor-pointer">➕ افزودن عضو جدید</button>
          </div>

          <div className="bg-white rounded-2xl border overflow-hidden">
            <table className="w-full text-right">
              <thead className="bg-slate-50 text-slate-500 font-bold border-b">
                <tr>
                  <th className="p-4">نام کاربر</th>
                  <th className="p-4">ایمیل</th>
                  <th className="p-4">دپارتمان فعال</th>
                  <th className="p-4">وضعیت حساب</th>
                  <th className="p-4 text-center">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y text-slate-700">
                {users.map((u: any) => (
                  <tr key={u.id} className="hover:bg-slate-50/50">
                    <td className="p-4 font-bold">{u.name}</td>
                    <td className="p-4 font-mono">{u.email}</td>
                    <td className="p-4 font-bold text-indigo-600">{departments.find(d => d.id === u.department_id)?.name || '🔴 بدون دپارتمان'}</td>
                    <td className="p-4">
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${u.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>{u.status === 'active' ? 'فعال' : 'غیرفعال'}</span>
                    </td>
                    <td className="p-4 text-center">
                      <button onClick={() => openUserEdit(u)} className="bg-slate-900 text-white px-3 py-1.5 rounded-lg font-bold cursor-pointer">🛠️ مدیریت پرمیشن و پروفایل</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================== تب دوم: دپارتمان‌ها ==================== */}
      {panelTab === 'departments' && (
        <div className="space-y-4">
          <div className="bg-white p-6 rounded-2xl border flex justify-between items-center">
            <div>
              <h2 className="text-base font-black text-slate-800">🏢 پیکربندی ساختار دپارتمان‌ها</h2>
              <p className="text-slate-400 text-[11px] mt-0.5">تعیین منوهای مجاز و پرمیشن‌های الگو (Template) برای هر حوزه کاری</p>
            </div>
            <button onClick={() => setEditingDept({ name: '', slug: '', permissions: { menu_leads: true, menu_reports: false, view_all_leads: false } })} className="bg-emerald-600 text-white p-2 rounded-xl font-bold cursor-pointer">➕ ساخت دپارتمان جدید</button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {departments.map((dept: any) => (
              <div key={dept.id} className="bg-white p-5 rounded-2xl border shadow-2xs space-y-3">
                <div className="flex justify-between items-center border-b pb-2">
                  <h3 className="font-black text-slate-800 text-sm">🏢 {dept.name} <span className="text-slate-400 font-mono text-[10px]">({dept.slug})</span></h3>
                  <button onClick={() => setEditingDept(dept)} className="text-indigo-600 font-bold hover:underline cursor-pointer">⚙️ پیکربندی پرمیشن الگو</button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {Object.keys(dept.permissions).map(k => dept.permissions[k] && (
                    <span key={k} className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono text-[10px]">{k}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 🛠️ مودال مدیریت و ویرایش کاربران (User Profile & Permissions Overrides) */}
      {editingUser && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center animate-fadeIn">
          <div className="bg-white p-6 rounded-2xl shadow-2xl w-full max-w-md space-y-4 border max-h-[90vh] overflow-y-auto">
            <h3 className="font-black text-slate-800 text-sm">👤 گارد کاربر: {editingUser.name}</h3>

            <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border">
              <label className="font-bold text-slate-600">نقش سیستم:
                <select className="w-full p-2 border rounded-lg mt-1 bg-white font-bold" value={editingUser.role} onChange={e => setEditingUser({ ...editingUser, role: e.target.value })}>
                  <option value="agent">💼 کارشناس فروش</option>
                  <option value="supervisor">👑 ناظر کل</option>
                </select>
              </label>
              <label className="font-bold text-slate-600">وضعیت حساب:
                <select className="w-full p-2 border rounded-lg mt-1 bg-white font-bold" value={editingUser.status} onChange={e => setEditingUser({ ...editingUser, status: e.target.value })}>
                  <option value="active">🟢 فعال</option>
                  <option value="inactive">🚫 غیرفعال (Deactive)</option>
                </select>
              </label>

              {/* 🚀 حل باگ: دپارتمان کلاینت به راحتی تعویض می‌شود */}
              <label className="font-bold text-slate-600 col-span-2">🏢 انتساب به دپارتمان:
                <select className="w-full p-2 border rounded-lg mt-1 bg-white font-bold text-indigo-600 outline-none" value={editingUser.department_id || ''} onChange={e => setEditingUser({ ...editingUser, department_id: e.target.value })}>
                  <option value="">🔴 بدون دپارتمان آزاد</option>
                  {departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </label>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-600">کلمه عبور جدید (اختیاری):</label>
              <input type="text" placeholder="فقط در صورت نیاز پر کنید..." className="w-full p-2 border rounded-lg bg-slate-50 font-mono text-center" value={newPassword} onChange={e => setNewPassword(e.target.value)} />
            </div>

            {/* بخش پرمیشن‌های اختصاصی خود کاربر (User Overrides) */}
            <div className="p-4 bg-indigo-50/50 rounded-xl border border-indigo-100 space-y-3">
              <h4 className="font-black text-indigo-700 text-[10px] border-b pb-1">🎛️ استثناهای دسترسی کاربر (User Overrides)</h4>
              <div className="grid grid-cols-2 gap-2">
                {Object.keys(editingUser.permissions_parsed || {}).map(k => (
                  <label key={k} className="flex items-center justify-between bg-white p-2 rounded-lg border text-[10px] font-bold cursor-pointer">
                    <span>{k === 'view_all_leads' ? '🔓 دیدن همه لیدها' : k === 'delete_leads' ? '🗑️ حذف لید' : k === 'export_excel' ? '📊 اکسل' : k}</span>
                    <input type="checkbox" checked={editingUser.permissions_parsed[k] || false} onChange={() => {
                      const updated = { ...editingUser.permissions_parsed, [k]: !editingUser.permissions_parsed[k] };
                      setEditingUser({ ...editingUser, permissions_parsed: updated });
                    }} />
                  </label>
                ))}
              </div>
            </div>

            <div className="pt-2 flex gap-2">
              <button onClick={handleUserUpdate} className="flex-1 bg-indigo-600 text-white p-2.5 rounded-xl font-bold cursor-pointer">💾 ذخیره تغییرات کاربر</button>
              <button onClick={() => setEditingUser(null)} className="bg-slate-100 text-slate-600 p-2.5 rounded-xl font-medium cursor-pointer">انصراف</button>
            </div>
          </div>
        </div>
      )}

      {/* 🏢 مودال ایجاد / ویرایش دسترسی‌های دپارتمان */}
      {editingDept && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center animate-fadeIn">
          <form onSubmit={handleSaveDepartment} className="bg-white p-6 rounded-2xl shadow-2xl w-full max-w-md space-y-4 border">
            <h3 className="font-black text-slate-800 text-sm">🏢 تنظیمات الگو دپارتمان: {editingDept.name || 'جدید'}</h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <label className="font-bold">نام دپارتمان:<input type="text" required className="w-full p-2 border rounded-lg mt-1 bg-slate-50" value={editingDept.name} onChange={e => setEditingDept({ ...editingDept, name: e.target.value })} /></label>
              <label className="font-bold">شناسه لاتین (Slug):<input type="text" required className="w-full p-2 border rounded-lg mt-1 bg-slate-50 font-mono" value={editingDept.slug} onChange={e => setEditingDept({ ...editingDept, slug: e.target.value })} /></label>
            </div>

            {/* تنظیم دسترسی منوها و ماژول‌ها برای کل دپارتمان */}
            <div className="p-4 bg-emerald-50/50 rounded-xl border border-emerald-100 space-y-2">
              <h4 className="font-black text-emerald-700 text-[10px] border-b pb-1">📋 منوها و پورتال‌های مجاز این دپارتمان</h4>
              <div className="grid grid-cols-2 gap-2">
                {['menu_leads', 'menu_reports', 'menu_technical', 'view_all_leads', 'delete_leads', 'export_excel'].map(k => (
                  <label key={k} className="flex items-center justify-between bg-white p-2 rounded-lg border text-[10px] font-bold cursor-pointer">
                    <span>{k.startsWith('menu_') ? `📂 منوی ${k.replace('menu_', '')}` : `🔑 پرمیشن ${k}`}</span>
                    <input type="checkbox" checked={editingDept.permissions[k] || false} onChange={() => {
                      const updated = { ...editingDept.permissions, [k]: !editingDept.permissions[k] };
                      setEditingDept({ ...editingDept, permissions: updated });
                    }} />
                  </label>
                ))}
              </div>
            </div>

            <div className="pt-2 flex gap-2">
              <button type="submit" className="flex-1 bg-emerald-600 text-white p-2.5 rounded-xl font-bold cursor-pointer">💾 ذخیره الگو دپارتمان</button>
              <button type="button" onClick={() => setEditingDept(null)} className="bg-slate-100 text-slate-600 p-2.5 rounded-xl font-medium cursor-pointer">انصراف</button>
            </div>
          </form>
        </div>
      )}

      {/* مودال افزودن کاربر جدید */}
      {showCreateUserModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center animate-fadeIn">
          <form onSubmit={handleCreateUser} className="bg-white p-6 rounded-2xl shadow-2xl w-full max-w-sm space-y-3 border">
            <h3 className="font-black text-slate-800 text-sm">➕ عضویت کارشناس جدید</h3>
            <label className="block font-bold">نام و نام خانوادگی:<input type="text" required className="w-full p-2 border rounded-lg mt-1" value={newUser.name} onChange={e => setNewUser({ ...newUser, name: e.target.value })} /></label>
            <label className="block font-bold">ایمیل کاربری:<input type="email" required className="w-full p-2 border rounded-lg mt-1 font-mono text-left" value={newUser.email} onChange={e => setNewUser({ ...newUser, email: e.target.value })} /></label>
            <label className="block font-bold">کلمه عبور:<input type="password" required className="w-full p-2 border rounded-lg mt-1 font-mono text-center" value={newUser.password} onChange={e => setNewUser({ ...newUser, password: e.target.value })} /></label>
            <label className="block font-bold">دپارتمان اولیه:
              <select className="w-full p-2 border rounded-lg mt-1 font-bold" value={newUser.department_id} onChange={e => setNewUser({ ...newUser, department_id: e.target.value })}>
                <option value="">انتخاب کنید...</option>
                {departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
            </label>
            <label className="block text-slate-700 font-bold mb-1 text-[11px]">
  📞 شماره داخلی مرکز تلفن (VoIP Extension) *
  <input
    type="text"
    required
    placeholder="مثال: 101"
    className="w-full mt-1 p-2.5 border rounded-xl font-mono text-center tracking-widest text-indigo-600 bg-slate-50 focus:bg-white transition-all text-[11px]"
    value={newUser.voip_extension || ''}
    onChange={(e) => setNewUser({ ...newUser, voip_extension: e.target.value })}
  />
</label>
            <div className="pt-2 flex gap-2">
              <button type="submit" className="flex-1 bg-indigo-600 text-white p-2.5 rounded-xl font-bold cursor-pointer">💾 ثبت</button>
              <button type="button" onClick={() => setShowCreateModal(false)} className="bg-slate-100 text-slate-600 p-2.5 rounded-xl font-medium cursor-pointer">انصراف</button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}

const styles = {
  label: { display: 'flex', flexDirection: 'column' as const, fontSize: '12px', fontWeight: '500', color: '#475569' },
};