'use client';
import React, { useState, useEffect } from 'react';

export default function WorkflowsPage() {
  const [agents, setAgents] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [selectedDept, setSelectedDept] = useState(1);
  const [highScore, setHighScore] = useState(80);
  const [vipRole, setVipRole] = useState('senior_agent');

  useEffect(() => {
    // لود زنده دپارتمان‌ها و کارشناسان ویپ
    fetch('http://127.0.0.1:8000/api/next/departments').then(res => res.json()).then(d => setDepartments(d.data || []));
    fetch('http://127.0.0.1:8000/api/next/agents/voip-status').then(res => res.json()).then(d => setAgents(d.data || []));
  }, []);

  const handleAssignDept = async (agentId: number, deptId: number) => {
    await fetch('http://127.0.0.1:8000/api/next/workflows/assign-agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ agent_id: agentId, department_id: deptId })
    });
    alert('🔄 کارشناس به دپارتمان متصل شد.');
  };

  const handleSaveFlow = async () => {
    await fetch('http://127.0.0.1:8000/api/next/workflows/store', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: `قانون داینامیک دپارتمان ${selectedDept}`,
        department_id: selectedDept,
        flow_rules: { high_score_threshold: highScore, VIP_agent_role: vipRole }
      })
    });
    alert('🚀 فلوچارت داینامیک این دپارتمان با موفقیت در هسته هوش مصنوعی مستقر شد.');
  };

  return (
    <div className="p-6 space-y-6 font-sans text-[11px]" dir="rtl">
      <h1 className="text-sm font-black text-slate-800">🎛️ اتاق فرمان ساختار دپارتمان‌ها و فلوچارت ارجاع داینامیک</h1>
      
      <div className="grid grid-cols-3 gap-6">
        {/* ۱. ساختار درختی و چیدمان فلوچارت */}
        <div className="col-span-2 bg-white p-5 rounded-2xl border space-y-4">
          <h2 className="font-bold text-slate-700 border-b pb-2 flex items-center gap-1.5">📐 بوم تنظیم شروط فلوچارت ارجاع (Workflow Builder)</h2>
          <label className="block font-bold">انتخاب دپارتمان جهت اعمال فلو:
            <select className="w-full mt-1 p-2 border rounded-xl font-bold bg-slate-50" value={selectedDept} onChange={e => setSelectedDept(Number(e.target.value))}>
              {departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </label>
          
          <div className="p-4 bg-violet-50/50 rounded-xl border border-violet-100 space-y-3">
            <div className="font-bold text-violet-800 text-xs">🧠 گره شرطی هوش مصنوعی (AI Conditional Node):</div>
            <p className="text-[10px] text-slate-500">اگر امتیاز پرونده (Lead Score) متقاضی از حد زیر بیشتر شد، فلوچارت مسیر ارجاع را به رول VIP تغییر دهد:</p>
            <input type="number" className="p-2 border rounded-lg bg-white font-bold font-mono text-center w-24 text-indigo-600" value={highScore} onChange={e => setHighScore(Number(e.target.value))} />
            <span className="mx-2 font-bold">امتیاز</span>
            
            <div className="mt-2">
              <span className="font-bold">ارجاع شود به رول فلوچارت:</span>
              <select className="p-2 border rounded-lg bg-white font-bold mx-2" value={vipRole} onChange={e => setVipRole(e.target.value)}>
                <option value="senior_agent">👑 کارشناس ارشد دپارتمان</option>
                <option value="call_center">💼 مشاور اولیه معمولی</option>
              </select>
            </div>
          </div>

          <button onClick={handleSaveFlow} className="bg-indigo-900 text-white font-bold p-3 rounded-xl hover:bg-indigo-950 transition-all cursor-pointer">
            ⚡ استقرار و اعمال نهایی فلوچارت در دیتابیس
          </button>
        </div>

        {/* ۲. لیست کارشناسان و تخصیص دپارتمان */}
        <div className="bg-white p-5 rounded-2xl border space-y-4">
          <h2 className="font-bold text-slate-700 border-b pb-2">👥 دپارتمان کارشناسان پرفکس</h2>
          <div className="space-y-3 max-h-[400px] overflow-y-auto">
            {agents.map((agent: any) => (
              <div key={agent.id} className="p-3 bg-slate-50 rounded-xl border flex flex-col gap-2">
                <div className="font-bold text-slate-800 text-[11px]">{agent.name} <span className="font-mono text-slate-400">({agent.extension})</span></div>
                <select 
                  className="p-1.5 border rounded-lg bg-white font-bold text-indigo-600"
                  onChange={(e) => handleAssignDept(agent.id, Number(e.target.value))}
                  defaultValue={agent.department_id || ""}
                >
                  <option value="" disabled>انتخاب دپارتمان...</option>
                  {departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}