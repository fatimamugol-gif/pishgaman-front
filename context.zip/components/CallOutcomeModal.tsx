'use client';
import React, { useState } from 'react';

export default function CallOutcomeModal({ lead, taskId, onClose, onSuccess }: any) {
  const [outcome, setOutcome] = useState('consultation');
  const [persona, setPersona] = useState('Goal-Oriented');
  const [reqDate, setReqDate] = useState('');
  const [reqTime, setReqTime] = useState('');
  const [nextStep, setNextStep] = useState('');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const token = localStorage.getItem('token');

    let finalOutcome = outcome;
    if (outcome === 'not_convenient') {
      finalOutcome = reqDate && reqTime ? 'not_convenient_has_time' : 'not_convenient_no_time';
    }

    try {
      const res = await fetch('http://127.0.0.1:8000/api/next/leads/call-outcome', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lead_id: lead.id,
          task_id: taskId,
          outcome: finalOutcome,
          persona: persona,
          requested_date: reqDate,
          requested_time: reqTime,
          next_step_note: `[اقدام بعدی: ${nextStep}] - یادداشت: ${note}`
        })
      });
      if (res.ok) {
        alert('✅ تسک بسته شد و فالوآپ بعدی با موفقیت در سیستم زمان‌بندی شد.');
        onSuccess();
        onClose();
      }
    } catch (err) {
      alert('خطا در ثبت نتیجه');
    } finally {
      setLoading(false);
    }
  };

  // متد ارسال سیگنال تماس دوطرفه به AMI آستریسک
  const handleLiveClickToDial = async () => {
    const token = localStorage.getItem('token');
    try {
      const res = await fetch('http://127.0.0.1:8000/api/next/voip/click-to-dial', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_phone: lead.phone,
          lead_id: lead.id
        })
      });
      const data = await res.json();
      if (data.status === 'success') {
        alert('☎️ ' + data.message);
      } else {
        alert('❌ ' + data.message);
      }
    } catch (err) {
      alert('خطا در شلیک دستور به AMI آستریسک');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fadeIn" dir="rtl">
      <div className="bg-white rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden border border-slate-100 font-sans text-[11px]">

        {/* هدر پاپ‌آ‌پ */}
        <div className="bg-slate-50 p-4 border-b flex justify-between items-center">
          <div>
            <h2 className="text-sm font-black text-slate-800 flex items-center gap-2">📞 ثبت وضعیت‌سنجی تماس (Follow-up)</h2>
            <p className="text-[10px] text-slate-500 mt-0.5">پرونده: <span className="font-bold text-indigo-600">{lead.name}</span> | تلفن: <span className="font-mono">{lead.phone}</span></p>
          </div>
          <button type="button" onClick={onClose} className="w-6 h-6 bg-white border rounded-full hover:bg-rose-50 text-slate-400 hover:text-rose-600 font-bold transition-colors">×</button>
        </div>

        {/* بدنه فرم */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">

          {/* ردیف انتخاب نتیجه تماس (Outcome) */}
          <div className="bg-slate-50/60 p-3 rounded-xl border border-slate-100 flex items-center justify-between">
            <label className="font-bold text-slate-700">نتیجه تماس (Outcome):</label>
            <div className="flex gap-3">
              <label className="flex items-center gap-1.5 cursor-pointer bg-white px-3 py-1.5 rounded-lg border text-[10px] font-bold"><input type="radio" name="outcome" checked={outcome === 'no_answer'} onChange={() => setOutcome('no_answer')} className="accent-rose-500" /> 🚫 عدم پاسخگویی</label>
              <label className="flex items-center gap-1.5 cursor-pointer bg-white px-3 py-1.5 rounded-lg border text-[10px] font-bold"><input type="radio" name="outcome" checked={outcome === 'not_convenient'} onChange={() => setOutcome('not_convenient')} className="accent-amber-500" /> ⏳ مساعد نبودن</label>
              <label className="flex items-center gap-1.5 cursor-pointer bg-white px-3 py-1.5 rounded-lg border text-[10px] font-bold border-indigo-200"><input type="radio" name="outcome" checked={outcome === 'consultation'} onChange={() => setOutcome('consultation')} className="accent-indigo-600" /> 🗣️ مشاوره (پرسونا)</label>
            </div>
          </div>

          {/* فیلدهای پویا وابسته به انتخاب بازه یا پرسونا */}
          <div className="grid grid-cols-2 gap-4">
            {outcome === 'not_convenient' && (
              <>
                <label className="block font-bold text-slate-600">تاریخ درخواستی مشتری:<input type="text" className="w-full mt-1 p-2 border rounded-lg bg-slate-50 font-mono text-center outline-none" placeholder="1405/03/25" value={reqDate} onChange={e => setReqDate(e.target.value)} /></label>
                <label className="block font-bold text-slate-600">ساعت درخواستی:<input type="time" className="w-full mt-1 p-2 border rounded-lg bg-slate-50 font-mono text-center outline-none" value={reqTime} onChange={e => setReqTime(e.target.value)} /></label>
              </>
            )}

            {outcome === 'consultation' && (
              <label className="col-span-2 block font-bold text-slate-600">
                تشخیص تیپ شخصیتی (Persona):
                <select className="w-full mt-1 p-2 border rounded-lg bg-white outline-none font-bold text-indigo-600 cursor-pointer" value={persona} onChange={e => setPersona(e.target.value)}>
                  <option value="Goal-Oriented">هدف‌گرا (Goal Oriented) - سریع</option>
                  <option value="Analytical">تحلیلی (Analytical) - مستندات و مقایسه</option>
                  <option value="Safety-Oriented">امنیت‌محور (Safety Oriented) - ضمانت</option>
                  <option value="Explorer">کاوش‌گر (Explorer) - تنوع طلب</option>
                  <option value="Skeptic">شکاک (Skeptic) - نیازمند شواهد</option>
                  <option value="Budget-Conscious">حساس به هزینه (Budget-Conscious)</option>
                  <option value="Family-First">خانواده‌محور (Family-First)</option>
                  <option value="Fast-Track">فوری/عجول (Fast-Track)</option>
                  <option value="Undecided/Passive">بلاتکلیف (Undecided/Passive)</option>
                  <option value="Opportunity-Driven">فرصت‌محور (Opportunity-Driven)</option>
                  <option value="Case-Study-Seeker">کیس استادی (Case Study Seeker)</option>
                </select>
              </label>
            )}
          </div>

          <label className="block font-bold text-slate-600">گام بعدی (Next Step):
            <input type="text" className="w-full mt-1 p-2 border rounded-lg outline-none font-medium" placeholder="برای تماس بعدی چه چیزی پیگیری شود؟" value={nextStep} onChange={e => setNextStep(e.target.value)} required={outcome === 'consultation'} />
          </label>

          <label className="block font-bold text-slate-600">یادداشت گزارش مشاوره (Note):
            <textarea rows={3} className="w-full mt-1 p-2 border rounded-lg outline-none leading-relaxed font-medium" placeholder="خلاصه مکالمات و نیازمندی‌ها..." value={note} onChange={e => setNote(e.target.value)}></textarea>
          </label>

          {/* 🎯 فوتر پاپ‌آ‌پ: چیدمان دقیقاً کپی عکس صفحه ۸ داکیومنت شما */}
          <div className="border-t pt-4 flex justify-between items-center select-none">
            
            {/* سمت راست: دکمه‌های عملیاتی اصلی */}
            <div className="flex gap-2">
              <button 
                type="submit" 
                disabled={loading} 
                className="bg-indigo-900 hover:bg-indigo-950 text-white font-bold px-4 py-2 rounded-xl transition-all shadow-xs cursor-pointer text-xs"
              >
                {loading ? '⏳ در حال پردازش...' : 'Submit Outcome 💾'}
              </button>
              
              <button 
                type="button" 
                onClick={handleLiveClickToDial}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl transition-all shadow-xs flex items-center gap-1 cursor-pointer text-xs"
              >
                <span>📞</span> Call (dispatch)
              </button>
              
              <button 
                type="button" 
                onClick={() => window.open(`/dashboard/leads`, '_blank')}
                className="bg-purple-100 hover:bg-purple-200 text-purple-700 font-bold px-4 py-2 rounded-xl transition-all cursor-pointer text-xs"
              >
                Open Lead ↗️
              </button>
            </div>

            {/* سمت چپ: دکمه خروج/بستن مستقل */}
            <button 
              type="button" 
              onClick={onClose} 
              className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold px-4 py-2 rounded-xl transition-all cursor-pointer text-xs"
            >
              بستن
            </button>

          </div>
        </form>
      </div>
    </div>
  );
}