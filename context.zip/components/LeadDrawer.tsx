'use client';

import React, { useState, useEffect } from 'react';

interface LeadDrawerProps {
  lead: any;
  onClose: () => void;
  onUpdate: (updatedLead: any) => Promise<void>;
}

export default function LeadDrawer({ lead, onClose, onUpdate }: LeadDrawerProps) {
  const [selectedLead, setSelectedLead] = useState<any>({ ...lead });
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'reminders' | 'tasks'>('profile');
  
  const [leadReminders, setLeadReminders] = useState<any[]>([]);
  const [leadTasks, setLeadTasks] = useState<any[]>([]);

  const [newReminder, setNewReminder] = useState({ title: '', description: '', date: '', time: '09:00' });
  const [newTask, setNewTask] = useState({ title: '', date: '' });

  const fetchLeadSubData = async (leadId: number) => {
    const token = localStorage.getItem('token');
    const authHeaders = { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' };
    try {
      const remRes = await fetch(`http://127.0.0.1:8000/api/next/leads/${leadId}/reminders`, { headers: authHeaders });
      const remData = await remRes.json();
      if (remData.status === 'success') setLeadReminders(remData.data || []);

      const taskRes = await fetch(`http://127.0.0.1:8000/api/next/leads/${leadId}/tasks`, { headers: authHeaders });
      const taskData = await taskRes.json();
      if (taskData.status === 'success') setLeadTasks(taskData.data || []);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    setSelectedLead({ ...lead });
    setIsEditing(false);
    if (lead?.id) fetchLeadSubData(lead.id);
  }, [lead]);

  const handleAddReminder = async () => {
    const token = localStorage.getItem('token');
    await fetch('http://127.0.0.1:8000/api/next/reminders/store', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({
        lead_id: selectedLead.id,
        title: newReminder.title,
        description: newReminder.description,
        reminder_date_shamsi: newReminder.date,
        reminder_time: newReminder.time
      })
    });
    alert('یادآور ثبت شد.');
    setNewReminder({ title: '', description: '', date: '', time: '09:00' });
    fetchLeadSubData(selectedLead.id);
  };

  const handleAddTask = async () => {
    if (!newTask.title) return alert('عنوان وظیفه را وارد کنید.');
    const token = localStorage.getItem('token');
    try {
      const res = await fetch('http://127.0.0.1:8000/api/next/tasks', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ lead_id: selectedLead.id, task_title: newTask.title, due_date_shamsi: newTask.date }),
      });
      if (res.ok) {
        alert('وظیفه ثبت شد.');
        setNewTask({ title: '', date: '' });
        fetchLeadSubData(selectedLead.id);
      }
    } catch (error) { console.error(error); }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex justify-start animate-fadeIn" dir="rtl">
      <div className="bg-white w-full max-w-2xl h-full shadow-2xl flex flex-col p-6 overflow-y-auto border-r text-[11px]">
        
        {/* هدر دراور */}
        <div className="flex justify-between items-center border-b pb-3 mb-4">
          <div>
            <h2 className="text-base font-black text-slate-800">👤 شناسنامه جامع و ۳۶۰ درجه متقاضی</h2>
            <p className="text-xs text-indigo-600 font-bold mt-0.5">{selectedLead.name} ({selectedLead.phone})</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 font-bold text-lg cursor-pointer">×</button>
        </div>

        {/* سوئیچ تب‌ها */}
        <div className="flex gap-2 border-b pb-3 mb-4 select-none">
          <button onClick={() => setActiveTab('profile')} className={`flex-1 py-2 rounded-xl font-bold transition-all cursor-pointer ${activeTab === 'profile' ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-50 text-slate-600'}`}>👤 شناسنامه و وضعیت تاهل</button>
          <button onClick={() => setActiveTab('reminders')} className={`flex-1 py-2 rounded-xl font-bold transition-all cursor-pointer ${activeTab === 'reminders' ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-50 text-slate-600'}`}>🔔 یادآورها ({leadReminders.length})</button>
          <button onClick={() => setActiveTab('tasks')} className={`flex-1 py-2 rounded-xl font-bold transition-all cursor-pointer ${activeTab === 'tasks' ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-50 text-slate-600'}`}>✅ وظایف ({leadTasks.length})</button>
        </div>

        {/* محتوای تب‌ها */}
        <div className="flex-1">
          {activeTab === 'profile' && (
            <div className="space-y-4 pb-10">
              {isEditing ? (
                /* ================= پنل ویرایش اطلاعات (Editor Mode) ================= */
                <div className="space-y-4">
                  
                  {/* بخش اول: اطلاعات فردی */}
                  <div className="bg-slate-50 p-4 rounded-xl border space-y-3">
                    <h4 className="font-bold text-indigo-600 border-b pb-1">📞 هویت و اطلاعات ارتباطی</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="flex flex-col gap-1">نام و نام خانوادگی:<input type="text" className="p-2 border rounded-lg bg-white font-bold" value={selectedLead.name || ''} onChange={e => setSelectedLead({ ...selectedLead, name: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">تلفن همراه اول:<input type="text" className="p-2 border rounded-lg text-left bg-white font-mono" value={selectedLead.phone || ''} onChange={e => setSelectedLead({ ...selectedLead, phone: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">تلفن همراه دوم:<input type="text" className="p-2 border rounded-lg text-left bg-white font-mono" value={selectedLead.secondary_phone || ''} onChange={e => setSelectedLead({ ...selectedLead, secondary_phone: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">شهر محل سکونت:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.current_city || ''} onChange={e => setSelectedLead({ ...selectedLead, current_city: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">سن متقاضی:<input type="number" className="p-2 border rounded-lg text-center bg-white" value={selectedLead.age || ''} onChange={e => setSelectedLead({ ...selectedLead, age: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">وضعیت نظام وظیفه:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.military_status || ''} onChange={e => setSelectedLead({ ...selectedLead, military_status: e.target.value })} /></label>
                    </div>
                  </div>

                  {/* 💍 بخش جدید و درخواستی: وضعیت تاهل و خانواده (فوق کامل) */}
                  <div className="bg-pink-50/30 p-4 rounded-xl border border-pink-100 space-y-3">
                    <h4 className="font-bold text-pink-700 border-b pb-1">💍 وضعیت تاهل، همسر و فرزندان</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="flex flex-col gap-1">وضعیت تاهل:
                        <select className="p-2 border rounded-lg bg-white font-bold text-slate-700" value={selectedLead.marital_status || 'single'} onChange={e => setSelectedLead({ ...selectedLead, marital_status: e.target.value })}>
                          <option value="single">مجرد</option>
                          <option value="married">متاهل</option>
                          <option value="divorced">مطلقه / فوت همسر</option>
                        </select>
                      </label>
                      <label className="flex flex-col gap-1">تعداد فرزندان:<input type="number" className="p-2 border rounded-lg text-center bg-white" value={selectedLead.children_count || '0'} onChange={e => setSelectedLead({ ...selectedLead, children_count: e.target.value })} /></label>
                    </div>

                    {/* فیلدهای پویا که اگر متاهل بود تکمیل آنها الزامی‌تر است */}
                    <div className="grid grid-cols-2 gap-3 pt-2 border-t border-dashed border-pink-100">
                      <label className="flex flex-col gap-1">نام و فامیل همسر:<input type="text" className="p-2 border rounded-lg bg-white" placeholder="در صورت تاهل" value={selectedLead.spouse_name || ''} onChange={e => setSelectedLead({ ...selectedLead, spouse_name: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">سن همسر:<input type="number" className="p-2 border rounded-lg text-center bg-white" value={selectedLead.spouse_age || ''} onChange={e => setSelectedLead({ ...selectedLead, spouse_age: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">تحصیلات همسر:<input type="text" className="p-2 border rounded-lg bg-white" placeholder="مثلا کارشناسی حسابداری" value={selectedLead.spouse_education || ''} onChange={e => setSelectedLead({ ...selectedLead, spouse_education: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">سطح زبان همسر:<input type="text" className="p-2 border rounded-lg bg-white" placeholder="مثلا انگلیسی B2 یا آلمانی A2" value={selectedLead.spouse_language_level || ''} onChange={e => setSelectedLead({ ...selectedLead, spouse_language_level: e.target.value })} /></label>
                      <label className="flex flex-col gap-1 col-span-2">آیا همسر متقاضی همراه سفر است؟
                        <select className="p-2 border rounded-lg bg-white font-medium text-slate-700" value={selectedLead.spouse_accompanying || 'yes'} onChange={e => setSelectedLead({ ...selectedLead, spouse_accompanying: e.target.value })}>
                          <option value="yes">بله، به عنوان همراه پرونده مهاجرت می‌کند</option>
                          <option value="no">خیر، در حال حاضر قصد همراهی ندارد</option>
                        </select>
                      </label>
                    </div>
                  </div>

                  {/* بخش تحصیلات */}
                  <div className="bg-slate-50 p-4 rounded-xl border space-y-3">
                    <h4 className="font-bold text-emerald-600 border-b pb-1">🎓 تحصیلات و سوابق آکادمیک</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="flex flex-col gap-1">آخرین مدرک تحصیلی:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.education_level || ''} onChange={e => setSelectedLead({ ...selectedLead, education_level: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">رشته تحصیلی:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.field_of_study || ''} onChange={e => setSelectedLead({ ...selectedLead, field_of_study: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">معدل کل (GPA):<input type="text" className="p-2 border rounded-lg text-center bg-white font-mono" value={selectedLead.gpa || ''} onChange={e => setSelectedLead({ ...selectedLead, gpa: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">سابقه کار و بیمه:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.work_and_insurance_history || ''} onChange={e => setSelectedLead({ ...selectedLead, work_and_insurance_history: e.target.value })} /></label>
                    </div>
                  </div>

                  {/* بخش زبان */}
                  <div className="bg-slate-50 p-4 rounded-xl border space-y-3">
                    <h4 className="font-bold text-amber-600 border-b pb-1">🗣️ سطوح و مدارک زبان متقاضی اصلی</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="flex flex-col gap-1">انگلیسی عمومی:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.english_level || ''} onChange={e => setSelectedLead({ ...selectedLead, english_level: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">مدرک انگلیسی:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.english_certified_level || ''} onChange={e => setSelectedLead({ ...selectedLead, english_certified_level: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">زبان آلمانی:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.german_level || ''} onChange={e => setSelectedLead({ ...selectedLead, german_level: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">مدرک آلمانی:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.german_certified_level || ''} onChange={e => setSelectedLead({ ...selectedLead, german_certified_level: e.target.value })} /></label>
                    </div>
                  </div>

                  {/* بخش مالی و مقصد */}
                  <div className="bg-slate-50 p-4 rounded-xl border space-y-3">
                    <h4 className="font-bold text-cyan-600 border-b pb-1">✈️ اهداف مهاجرتی و مالی</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="flex flex-col gap-1">کشور مقصد هدف:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.target_country || ''} onChange={e => setSelectedLead({ ...selectedLead, target_country: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">پلن مهاجرتی درخواست شده:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.requested_plan || ''} onChange={e => setSelectedLead({ ...selectedLead, requested_plan: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">تمکن مالی (تومان):<input type="number" className="p-2 border rounded-lg bg-white font-mono" value={selectedLead.financial_capability_toman || ''} onChange={e => setSelectedLead({ ...selectedLead, financial_capability_toman: e.target.value })} /></label>
                      <label className="flex flex-col gap-1">کانال کشف مجموعه:<input type="text" className="p-2 border rounded-lg bg-white" value={selectedLead.discovery_channel || ''} onChange={e => setSelectedLead({ ...selectedLead, discovery_channel: e.target.value })} /></label>
                    </div>
                  </div>

                  <button onClick={() => onUpdate(selectedLead).then(() => setIsEditing(false))} className="w-full bg-emerald-600 text-white p-3 rounded-xl font-bold shadow-md cursor-pointer hover:bg-emerald-700 transition-all">💾 ذخیره کل تغییرات چهل‌گانه شناسنامه</button>
                </div>
              ) : (
                /* ================= پنل نمایش لوکس ۳۶۰ درجه (Read-Only View) ================= */
                <div className="space-y-4">
                  
                  {/* کارت اطلاعات فردی */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                    <h4 className="font-bold text-indigo-600 border-b pb-1">👤 اطلاعات فردی و ارتباطی کلاینت</h4>
                    <div className="grid grid-cols-2 gap-2 text-slate-600">
                      <div>📌 <strong>نام متقاضی:</strong> <span className="text-slate-800 font-bold">{selectedLead.name}</span></div>
                      <div>📱 <strong>تلفن همراه اصلی:</strong> <span className="font-mono text-slate-800 font-bold">{selectedLead.phone}</span></div>
                      <div>📞 <strong>تلفن همراه دوم:</strong> <span className="font-mono">{selectedLead.secondary_phone || 'ثبت نشده'}</span></div>
                      <div>📍 <strong>شهر سکونت:</strong> <span className="text-slate-700">{selectedLead.current_city || '---'}</span></div>
                      <div>🎂 <strong>سن کلاینت:</strong> <span>{selectedLead.age || '---'} سال</span></div>
                      <div>🪖 <strong>وضعیت نظام وظیفه:</strong> <span>{selectedLead.military_status || '---'}</span></div>
                    </div>
                  </div>

                  {/* 💍 کارت نمایشی جدید: تاهل و مشخصات همسر */}
                  <div className="bg-pink-50/40 p-4 rounded-xl border border-pink-100/70 space-y-2">
                    <h4 className="font-bold text-pink-700 border-b pb-1">💍 وضعیت تاهل و ساختار خانواده کلاینت</h4>
                    <div className="grid grid-cols-2 gap-2 text-slate-600">
                      <div>Status <strong>وضعیت تاهل:</strong> <span className="text-pink-700 font-black">{selectedLead.marital_status === 'married' ? 'متاهل 👨‍👩‍👦' : selectedLead.marital_status === 'divorced' ? 'مطلقه / فوت همسر' : 'مجرد 🧍'}</span></div>
                      <div>👶 <strong>تعداد فرزندان همراه:</strong> <span className="font-mono font-bold text-slate-800">{selectedLead.children_count || '0'} فرزند</span></div>
                      
                      {selectedLead.marital_status === 'married' && (
                        <>
                          <div className="border-t pt-1 mt-1">👰 <strong>نام همسر:</strong> <span className="text-slate-800 font-bold">{selectedLead.spouse_name || '---'}</span></div>
                          <div className="border-t pt-1 mt-1">🎂 <strong>سن همسر:</strong> <span>{selectedLead.spouse_age || '---'} سال</span></div>
                          <div>🎓 <strong>تحصیلات همسر:</strong> <span>{selectedLead.spouse_education || '---'}</span></div>
                          <div>🗣 <strong>سطح زبان همسر:</strong> <span className="text-indigo-600 font-medium">{selectedLead.spouse_language_level || '---'}</span></div>
                          <div className="col-span-2 text-slate-500 font-medium bg-white/70 p-1.5 rounded border border-pink-50">
                            ✈️ وضعیت همراهی: <span className="text-slate-800 font-bold">{selectedLead.spouse_accompanying === 'no' ? 'خیر، همسر همسفر نیست' : 'بله، همسر در همین کیس مهاجرت می‌کند'}</span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>

                  {/* کارت تحصیلات */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                    <h4 className="font-bold text-emerald-600 border-b pb-1">🎓 آکادمیک، سوابق کاری و رزومه</h4>
                    <div className="grid grid-cols-2 gap-2 text-slate-600">
                      <div>🏛 <strong>آخرین مقطع تحصیلی:</strong> <span className="text-slate-800 font-bold">{selectedLead.education_level || '---'}</span></div>
                      <div>🔬 <strong>رشته تحصیلی:</strong> <span className="text-slate-800">{selectedLead.field_of_study || '---'}</span></div>
                      <div>📝 <strong>معدل کل فارغ‌التحصیلی:</strong> <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">{selectedLead.gpa || '---'}</span></div>
                      <div>💼 <strong>رزومه سابقه کار و بیمه:</strong> <span className="text-slate-700">{selectedLead.work_and_insurance_history || '---'}</span></div>
                    </div>
                  </div>

                  {/* کارت زبان */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                    <h4 className="font-bold text-amber-600 border-b pb-1">🗣️ سطوح و شایستگی‌های زبانی متقاضی اصلی</h4>
                    <div className="grid grid-cols-2 gap-2 text-slate-600">
                      <div>🇬🇧 <strong>سطح انگلیسی عمومی:</strong> <span>{selectedLead.english_level || '---'}</span></div>
                      <div>📜 <strong>مدرک رسمی انگلیسی:</strong> <span className="text-indigo-600 font-bold">{selectedLead.english_certified_level || '---'}</span></div>
                      <div>🇩🇪 <strong>سطح زبان آلمانی:</strong> <span>{selectedLead.german_level || '---'}</span></div>
                      <div>📜 <strong>مدرک رسمی آلمانی:</strong> <span className="text-indigo-600 font-bold">{selectedLead.german_certified_level || '---'}</span></div>
                    </div>
                  </div>

                  {/* کارت مالی و هدف */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-2">
                    <h4 className="font-bold text-cyan-600 border-b pb-1">✈️ اهداف مهاجرتی، مالی و کانال ورودی</h4>
                    <div className="grid grid-cols-2 gap-2 text-slate-600">
                      <div>🌍 <strong>کشور هدف:</strong> <span className="text-slate-800 font-bold">{selectedLead.target_country || '---'}</span></div>
                      <div>📋 <strong>نوع پلن درخواستی:</strong> <span className="text-indigo-600 font-bold">{selectedLead.requested_plan || '---'}</span></div>
                      <div>💰 <strong>میزان تمکن مالی:</strong> <span className="text-emerald-600 font-bold font-mono bg-emerald-50/50 px-1.5 py-0.5 rounded">{selectedLead.financial_capability_toman ? `${Number(selectedLead.financial_capability_toman).toLocaleString()} تومان` : '---'}</span></div>
                      <div>📡 <strong>کانال کشف (Discovery):</strong> <span className="text-slate-700">{selectedLead.discovery_channel || '---'}</span></div>
                    </div>
                  </div>

                  <button onClick={() => setIsEditing(true)} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white p-3 rounded-xl font-bold transition-all text-center cursor-pointer shadow-xs">✏️ ورود به پنل ادیتور و ویرایش ۳۶۰ درجه کل فیلدها</button>
                </div>
              )}
            </div>
          )}

          {/* تب یادآورها */}
          {activeTab === 'reminders' && (
            <div className="space-y-4 pb-10">
              <div className="bg-slate-50 p-4 rounded-xl border space-y-3">
                <h4 className="font-bold text-slate-700">⏰ تنظیم یادآور پیگیری سریع</h4>
                <div className="grid grid-cols-2 gap-3">
                  <input type="text" placeholder="موضوع پیگیری" className="p-2 border rounded-lg bg-white" value={newReminder.title} onChange={e => setNewReminder({ ...newReminder, title: e.target.value })} />
                  <input type="text" placeholder="تاریخ شمسی" className="p-2 border rounded-lg bg-white text-center font-mono" value={newReminder.date} onChange={e => setNewReminder({ ...newReminder, date: e.target.value })} />
                  <input type="time" className="p-2 border rounded-lg bg-white text-center font-mono" value={newReminder.time} onChange={e => setNewReminder({ ...newReminder, time: e.target.value })} />
                  <input type="text" placeholder="توضیحات تکمیلی..." className="p-2 border rounded-lg bg-white" value={newReminder.description} onChange={e => setNewReminder({ ...newReminder, description: e.target.value })} />
                </div>
                <button onClick={handleAddReminder} className="w-full bg-indigo-600 text-white p-2 rounded-lg font-bold cursor-pointer">⏰ ثبت ناتیفیکیشن روی سکوها</button>
              </div>
            </div>
          )}

          {activeTab === 'tasks' && (
            <div className="space-y-4 pb-10">
              <div className="bg-slate-50 p-4 rounded-xl border space-y-3">
                <h4 className="font-bold text-slate-800">➕ تعریف وظیفه و اتوماسیون پیگیری</h4>
                <div className="grid grid-cols-3 gap-3">
                  <input type="text" placeholder="عنوان وظیفه..." className="p-2 border rounded-lg col-span-2 bg-white" value={newTask.title} onChange={e => setNewTask({ ...newTask, title: e.target.value })} />
                  <input type="text" placeholder="ددلاین" className="p-2 border rounded-lg text-center bg-white font-mono" value={newTask.date} onChange={e => setNewTask({ ...newTask, date: e.target.value })} />
                </div>
                <button onClick={handleAddTask} className="w-full bg-emerald-600 text-white p-2.5 rounded-xl font-bold cursor-pointer">🚀 ثبت وظیفه متمرکز دپارتمان</button>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}